
public interface Agent {
	
	public String solve (Board board);

}
